from unittest import result
from urllib import response

from flask import Flask, render_template, request, session, redirect,make_response,flash,jsonify
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import update
from flask_bcrypt import Bcrypt
from dotenv import load_dotenv
from flask_mail import Mail, Message
from datetime import datetime, timedelta,timezone
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from flask_jwt_extended import (
    JWTManager,
    create_access_token,
    create_refresh_token,
    jwt_required,
    get_jwt_identity,
    get_jwt,
    get_csrf_token,
    decode_token,
    set_access_cookies,
    set_refresh_cookies,
    unset_jwt_cookies
)
from flask import redirect, url_for
import os
import requests
import secrets 
import hashlib
import time
import re
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_wtf.csrf import CSRFProtect
#---load telegram token----#  

load_dotenv()

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TELEGRAM_BOT_USERNAME = os.getenv("TELEGRAM_BOT_USERNAME")
#--flask--#
app=Flask(__name__)

# Photo upload configuration
UPLOAD_FOLDER = os.path.join(app.root_path, "static", "uploads")
ALLOWED_EXTENSIONS = {"jpg", "jpeg", "png", "webp"}

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = 20 * 1024 * 1024  # 20 MB

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
# JWT Configuration
app.config["JWT_SECRET_KEY"] = os.getenv("JWT_SECRET_KEY")
app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(minutes=15)
app.config["JWT_REFRESH_TOKEN_EXPIRES"] = timedelta(days=7)

jwt = JWTManager(app)
@app.before_request
def diagnose_refresh_csrf():
    if request.path != "/refresh":
        return

    refresh_cookie = request.cookies.get(
        app.config.get("JWT_REFRESH_COOKIE_NAME", "refresh_token_cookie")
    )

    csrf_cookie = request.cookies.get("csrf_refresh_token")
    refresh_cookies = request.cookies.getlist("refresh_token_cookie")
    csrf_cookies = request.cookies.getlist("csrf_refresh_token")

    app.logger.warning(
        "COOKIE COUNTS: refresh=%s | csrf=%s | MATCH_ANY=%s",
    len(refresh_cookies),
    len(csrf_cookies),
    any(
        decode_token(token).get("csrf") == csrf
        for token in refresh_cookies
        for csrf in csrf_cookies
       )
    )
    
    matches = []
    for token in refresh_cookies:
        try:
            matches.append(
                decode_token(token).get("csrf") == csrf_cookie
           )
        except Exception:
            matches.append(False)

    app.logger.warning("REFRESH COOKIE MATCHES: %s", matches)
    
    header_token = request.headers.get("X-CSRF-TOKEN")

    try:
        jwt_csrf = decode_token(refresh_cookie).get("csrf") if refresh_cookie else None

        app.logger.warning(
            "REFRESH DIAGNOSTIC: JWT=%s | COOKIE=%s | HEADER=%s | JWT_COOKIE_MATCH=%s | COOKIE_HEADER_MATCH=%s",
            bool(refresh_cookie),
            bool(csrf_cookie),
            bool(header_token),
            jwt_csrf == csrf_cookie if jwt_csrf else False,
            csrf_cookie == header_token if csrf_cookie else False
        )
        app.logger.warning(
            "REFRESH CSRF LENGTHS: JWT=%s | COOKIE=%s | HEADER=%s",
            len(jwt_csrf) if jwt_csrf else 0,
            len(csrf_cookie) if csrf_cookie else 0,
            len(header_token) if header_token else 0
        )
        app.logger.warning(
            "JWT COOKIE CONFIG: refresh_path=%s | csrf_path=%s | refresh_name=%s | csrf_name=%s",
            app.config.get("JWT_REFRESH_COOKIE_PATH"),
            app.config.get("JWT_REFRESH_CSRF_COOKIE_PATH"),
            app.config.get("JWT_REFRESH_COOKIE_NAME"),
            app.config.get("JWT_REFRESH_CSRF_COOKIE_NAME")
        )
    except Exception:
        app.logger.warning("REFRESH DIAGNOSTIC: JWT decoding failed")
@jwt.token_in_blocklist_loader
def check_if_token_revoked(jwt_header, jwt_payload):

    if jwt_payload["type"] != "refresh":
        return False

    token_record = RefreshToken.query.filter_by(
        jti=jwt_payload["jti"],
        username=jwt_payload["sub"]
    ).first()

    if not token_record:
        return True

    if token_record.revoked:
        return True

    if datetime.now(timezone.utc) >= token_record.expires_at.replace(
        tzinfo=timezone.utc
    ):
        return True

    return False

csrf = CSRFProtect(app) 
limiter = Limiter(
    get_remote_address,
    app=app,
    default_limits=[]
)

@app.after_request
def add_security_headers(response):

    response.headers["X-Frame-Options"] = "DENY"

    response.headers["X-Content-Type-Options"] = "nosniff"

    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Content-Security-Policy"] = (
    "default-src 'self'; "
    "script-src 'self' 'unsafe-inline'; "
    "style-src 'self' 'unsafe-inline'; "
    "img-src 'self' data: https:; "
    "font-src 'self' data:; "
    "connect-src 'self'; "
    "object-src 'none'; "
    "base-uri 'self'; "
    "frame-ancestors 'none'; "
    "form-action 'self'"
   )
    return response
#flask session security--#
app.secret_key = os.getenv("FLASK_SECRET_KEY")

if not app.secret_key:
    raise ValueError("FLASK_SECRET_KEY is missing fro the .env file.")

#session security--#
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SECURE"] = False
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["PERMANENT_SESSION_LIFETIME"] = 1800
# JWT cookie security
app.config["JWT_TOKEN_LOCATION"] = ["cookies"]
app.config["JWT_REFRESH_COOKIE_NAME"] = "refresh_token_cookie"
app.config["JWT_COOKIE_SECURE"] = False
app.config["JWT_COOKIE_HTTPONLY"] = True
app.config["JWT_COOKIE_SAMESITE"] = "Lax"
app.config["JWT_ACCESS_COOKIE_PATH"] = "/"
app.config["JWT_REFRESH_COOKIE_PATH"] = "/"
app.config["JWT_COOKIE_CSRF_PROTECT"] = True
app.config["JWT_CSRF_IN_COOKIES"] = True
app.config["JWT_ACCESS_CSRF_HEADER_NAME"] = "X-CSRF-TOKEN"
app.config["JWT_REFRESH_CSRF_HEADER_NAME"] = "X-CSRF-TOKEN"
# --- EMAIL CONFIGURATION --- #

app.config["MAIL_SERVER"] = "smtp.gmail.com"
app.config["MAIL_PORT"] = 587
app.config["MAIL_USE_TLS"] = True
app.config["MAIL_USERNAME"] = os.getenv("MAIL_USERNAME")
app.config["MAIL_PASSWORD"] = os.getenv("MAIL_PASSWORD")

mail = Mail(app)


app.config['SQLALCHEMY_DATABASE_URI']='sqlite:///database.db'

db=SQLAlchemy(app)
bcrypt = Bcrypt(app)
class User(db.Model):


    id=db.Column(db.Integer,primary_key=True)


    username=db.Column(db.String(100))


    email=db.Column(db.String(100))


    password=db.Column(db.String(100))

    bio = db.Column(db.String(500), nullable=True)

    profile_picture = db.Column(
        db.String(200),
        nullable=True,
        default="default.png"
    )

    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )


    failed_login_attempts = db.Column(
        db.Integer,
        default=0,
        nullable=False
    )

    locked_until = db.Column(
        db.DateTime,
        nullable=True
    )
    
    telegram_chat_id = db.Column(
        db.String(50),
        unique=True,
        nullable=True
    )

    telegram_verified = db.Column(
        db.Boolean,
        default=False,
        nullable=False
    )
class TelegramLinkCode(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    user_id = db.Column(
        db.Integer,
        db.ForeignKey('user.id'),
        nullable=False,
        unique=True
    )

    code_hash = db.Column(
        db.String(64),
        nullable=False,
        unique=True
    )

    expires_at = db.Column(
        db.DateTime,
        nullable=False
    )

    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )
class TelegramUpdateState(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    last_update_id = db.Column(
        db.Integer,
        nullable=False,
        default=0
    )
            
class FriendRequest(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    sender_id = db.Column(
        db.Integer,
        db.ForeignKey('user.id'),
        nullable=False
    )

    receiver_id = db.Column(
        db.Integer,
        db.ForeignKey('user.id'),
        nullable=False
    )

    status = db.Column(
        db.String(20),
        default='pending',
        nullable=False
    )

    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )

class Post(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    content = db.Column(db.String(2000), nullable=False)
    image_filename = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    author = db.relationship('User', backref='posts')

class Like(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    post_id = db.Column(db.Integer, db.ForeignKey('post.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (
        db.UniqueConstraint('user_id', 'post_id', name='unique_user_post_like'),
    )  
class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    post_id = db.Column(db.Integer, db.ForeignKey('post.id'), nullable=False)
    content = db.Column(db.String(1000), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    author = db.relationship('User')  
class ChatMessage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    content = db.Column(db.String(2000), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_read = db.Column(db.Boolean, default=False, nullable=False)
    sender = db.relationship('User', foreign_keys=[sender_id])
    receiver = db.relationship('User', foreign_keys=[receiver_id])
class SecurityLog(db.Model):

    id = db.Column(db.Integer, primary_key=True)

    username = db.Column(db.String(100))

    event = db.Column(db.String(100))

    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

    ip_address = db.Column(db.String(45))

class OTPVerification(db.Model):

    id = db.Column(db.Integer, primary_key=True)

    username = db.Column(db.String(100), nullable=False)

    otp_hash = db.Column(db.String(255), nullable=False)

    otp_type = db.Column(db.String(20), nullable=False)

    created_at = db.Column(db.DateTime, default=datetime.now(timezone.utc))

    expires_at = db.Column(db.DateTime, nullable=False)

    attempts = db.Column(db.Integer, default=0)

class RefreshToken(db.Model):

    id = db.Column(db.Integer, primary_key=True)

    jti = db.Column(db.String(36), unique=True, nullable=False)

    username = db.Column(db.String(100), nullable=False)

    created_at = db.Column(
        db.DateTime,
        default=lambda: datetime.now(timezone.utc)
    )

    expires_at = db.Column(db.DateTime, nullable=False)

    revoked = db.Column(db.Boolean, default=False)
 
def log_security_event(username, event):
    log = SecurityLog(
        username=username,
        event=event,
        ip_address=request.remote_addr
    )

    db.session.add(log) 
    db.session.commit()


def store_otp(username, otp, otp_type):

    # Remove previous unused OTPs for this user and OTP type
    OTPVerification.query.filter_by(
        username=username,
        otp_type=otp_type
    ).delete(synchronize_session=False)

    # Generate a new hashed OTP record
    otp_record = OTPVerification(
        username=username,
        otp_hash=generate_password_hash(str(otp)),
        otp_type=otp_type,
        expires_at=datetime.now(timezone.utc) + timedelta(minutes=5),
        attempts=0
    )

    # Save the new OTP
    db.session.add(otp_record)
    db.session.commit()

    print(f"{otp_type} OTP successfully saved!")
    print("OTP record ID:", otp_record.id)


with app.app_context():
    db.create_all()

    from sqlalchemy import inspect, text

    inspector = inspect(db.engine)

    post_columns = [
        column["name"]
        for column in inspector.get_columns("post")
    ]

    if "image_filename" not in post_columns:
        with db.engine.begin() as connection:
            connection.execute(
                text("ALTER TABLE post ADD COLUMN image_filename VARCHAR(255)")
            )
# ---- REGISTER ---- #

@app.route("/", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        # 1. Check required fields
        if not username or not email or not password:
            return render_template(
                "register.html",
                error="All fields are required."
            ), 400

        # 2. Validate username
        if not re.fullmatch(r"[A-Za-z0-9_]{3,20}", username):
            return render_template(
                "register.html",
                error="Username must be 3-20 characters and contain only letters, numbers or underscores."
            ), 400

        # 3. Validate email
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
            return render_template(
                "register.html",
                error="Please enter a valid email address."
            ), 400

        # 4. Validate password
        if len(password) < 8:
            return render_template(
                "register.html",
                error="Password must contain at least 8 characters."
            ), 400

        # 5. Check duplicate username or email
        existing_user = User.query.filter(
            (User.username == username) |
            (User.email == email)
        ).first()

        if existing_user:
            return render_template(
                "register.html",
                error="Username or email already exists."
            ), 409

        # 6. Hash password
        hashed_password = bcrypt.generate_password_hash(
            password
        ).decode("utf-8")

        # 7. Save new user
        new_user = User(
            username=username,
            email=email,
            password=hashed_password
        )

        db.session.add(new_user)
        db.session.commit()

        log_security_event(username, "USER_REGISTERED")

      # Start Telegram setup for this newly registered user
        session["telegram_setup_user_id"] = new_user.id

        flash('Account created! Now connect your Telegram account.', 'success')
        return redirect(url_for('connect_telegram'))
    return render_template("register.html")


#---LOGIN---#
@app.route("/login", methods=["GET", "POST"])
@limiter.limit("5 per minute", methods=["POST"])  # Limit to 5 login attempts per minute
def login():

    if request.method == "POST":

        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        if not username or not password:
            return render_template(
                "login.html",
                error="Username and password are required."
            ), 400
        user = User.query.filter_by(username=username).first()
        if user:
            now = datetime.now(timezone.utc)

            if user.locked_until:
                locked_time = user.locked_until

                if locked_time.tzinfo is None:
                    locked_time = locked_time.replace(tzinfo=timezone.utc)

                if now < locked_time:
                    log_security_event(username, "LOGIN_BLOCKED_ACCOUNT_LOCKED")
                    return "Account locked. Try again later.", 403

                user.locked_until = None 
                user.failed_login_attempts = 0
                db.session.commit()
        if user and bcrypt.check_password_hash(user.password, password):
            user.failed_login_attempts = 0
            user.locked_until = None
            db.session.commit()
       # --- Clear old authentication data ---
            session.pop("authenticated", None)
            session.pop("otp", None)
            session.pop("otp_time", None)
            session.pop("otp_attempts", None)
            session.pop("email_otp", None)
            session.pop("email_otp_time", None)
            session.pop("email_otp_attempts", None)

  

           #--generate rando telegram OTP--#
            log_security_event(username, "LOGIN_PASSWORD_SUCCESS")
            otp = secrets.randbelow(900000) + 100000

           # Store OTP securely in the database
            store_otp(username, otp, "telegram")

           # Keep username in session for the next authentication step
            session["username"] = username

            
            # Require the user's own Telegram account to be linked
            if not user.telegram_verified or not user.telegram_chat_id:
                flash('Please connect your Telegram account before logging in.', 'error')
                session["telegram_setup_user_id"] = user.id
                return redirect(url_for('connect_telegram'))

            chat_id = user.telegram_chat_id
            message = f"🔐 Your Triple Factor Authentication OTP is: {otp}"

            url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"

            data = {
                "chat_id": chat_id,
                "text": message
            }

            response = requests.post(url, json=data)

            
            

            return render_template("otp.html")

        else:
            if user:
                user.failed_login_attempts += 1

                log_security_event(username, "LOGIN_FAILED")

                if user.failed_login_attempts >= 5:
                    user.locked_until = datetime.now(timezone.utc) + timedelta(minutes=15)

                    log_security_event(username, "ACCOUNT_LOCKED")

                    db.session.commit()

                    return render_template(
                        "login.html",
                        error="Account locked for 15 minutes."
                    ), 403

                db.session.commit()

            else:
                log_security_event(username, "LOGIN_FAILED")

            return render_template(
                "login.html",
                error="Invalid username or password. Please try again."
            ), 401
    return render_template("login.html")



# --- TELEGRAM OTP VERIFICATION --- #

@app.route("/verify-otp", methods=["GET", "POST"])
@limiter.limit("5 per minute", methods=["POST"])
def verify_otp():

    if request.method == "POST":

        entered_otp = request.form.get("otp")
        username = session.get("username")

        # Check whether username exists in session
        if not username:
            return "Session expired. Please login again.", 401

        # Retrieve Telegram OTP record from database
        telegram_record = OTPVerification.query.filter_by(
            username=username,
            otp_type="telegram"
        ).order_by(OTPVerification.id.desc()).first()

        # Check whether OTP record exists
        if not telegram_record:
            return "OTP expired or invalid. Please login again."

        # Check OTP expiration
        expiry_time = telegram_record.expires_at.replace(
            tzinfo=timezone.utc
        )

        if datetime.now(timezone.utc) > expiry_time:

            db.session.delete(telegram_record)
            db.session.commit()

            log_security_event(username, "TELEGRAM_OTP_EXPIRED")

            return "Telegram OTP expired. Please login again."

        # Check maximum attempts
        if telegram_record.attempts >= 3:

            db.session.delete(telegram_record)
            db.session.commit()

            log_security_event(username, "TELEGRAM_OTP_TOO_MANY_ATTEMPTS")

            return "Too many incorrect OTP attempts. Please login again."

        # Verify entered OTP against stored hash
        if entered_otp and check_password_hash(
            telegram_record.otp_hash,
            entered_otp
        ):

            # OTP successfully verified: delete database record
            db.session.delete(telegram_record)
            db.session.commit()

            log_security_event(username, "TELEGRAM_OTP_SUCCESS")

            # Find user in database
            user = User.query.filter_by(username=username).first()

            if user:

                # Generate Email OTP
                email_otp = secrets.randbelow(900000) + 100000

                # Store Email OTP securely in the database
                store_otp(username, email_otp, "email")
                # Send Email OTP
                msg = Message(
                    subject="Triple Factor Authentication - Email OTP",
                    sender=app.config["MAIL_USERNAME"],
                    recipients=[user.email]
                )

                msg.body = f"""
Your Triple Factor Authentication Email OTP is: {email_otp}

Please enter this OTP to complete your login.
"""

                mail.send(msg)

                return render_template("email_otp.html")

            else:
                return "User not found."

        else:

            # Incorrect OTP: update attempts in database
            telegram_record.attempts += 1
            attempts = telegram_record.attempts

            log_security_event(username, "TELEGRAM_OTP_FAILED")

            if attempts >= 3:

                db.session.delete(telegram_record)
                db.session.commit()

                log_security_event(
                    username,
                    "TELEGRAM_OTP_TOO_MANY_ATTEMPTS"
                )

                return "Too many incorrect OTP attempts. Please login again."

            db.session.commit()

            return render_template(
                "otp.html",
                error=f"Invalid Telegram OTP. Attempt {attempts} of 3."
            )

    return render_template("otp.html")


# --- EMAIL OTP VERIFICATION --- #

@app.route("/verify-email-otp", methods=["GET", "POST"])
@limiter.limit("5 per minute", methods=["POST"])
def verify_email_otp():

    if request.method == "POST":

        entered_email_otp = request.form.get("email_otp")
        username = session.get("username")

        # Check whether username exists in session
        if not username:
            return "Session expired. Please login again.", 401

        # Retrieve Email OTP record from database
        email_record = OTPVerification.query.filter_by(
            username=username,
            otp_type="email"
        ).order_by(OTPVerification.id.desc()).first()

        # Check whether OTP record exists
        if not email_record:
            log_security_event(username, "EMAIL_OTP_INVALID_OR_MISSING")
            return "Email OTP expired or invalid. Please login again."

        # Check OTP expiration
        expiry_time = email_record.expires_at.replace(
            tzinfo=timezone.utc
        )

        if datetime.now(timezone.utc) > expiry_time:

            db.session.delete(email_record)
            db.session.commit()

            log_security_event(username, "EMAIL_OTP_EXPIRED")

            return "Email OTP expired. Please login again."

        # Check maximum attempts
        if email_record.attempts >= 3:

            db.session.delete(email_record)
            db.session.commit()

            log_security_event(username, "EMAIL_OTP_TOO_MANY_ATTEMPTS")

            return "Too many incorrect Email OTP attempts. Please login again."

        # Verify entered OTP against stored hash
        if entered_email_otp and check_password_hash(
            email_record.otp_hash,
            entered_email_otp
        ):

            # Delete OTP after successful verification
            db.session.delete(email_record)
            db.session.commit()

            log_security_event(username, "EMAIL_OTP_SUCCESS")

                 # All three authentication steps successfully verified
            session["authenticated"] = True
            session.permanent = True

      # Generate JWT tokens
            access_token = create_access_token(
                identity=str(username),
                fresh=True
            )
            refresh_token = create_refresh_token(
                identity=str(username)
            )

           # Decode refresh token to retrieve its claims
            refresh_data = decode_token(refresh_token)

          # Store refresh token details in database 
            new_refresh_token = RefreshToken(
                jti=refresh_data["jti"],
                username=username,
                expires_at=datetime.fromtimestamp(
                    refresh_data["exp"],
                    timezone.utc
                 )
             )

            db.session.add(new_refresh_token)
            db.session.commit()

            log_security_event(username, "MFA_COMPLETED_SUCCESSFULLY")
            log_security_event(username, "JWT_TOKENS_CREATED")


            response = make_response(
                redirect(url_for("dashboard"))
                )

            set_access_cookies(response, access_token)
            set_refresh_cookies(response, refresh_token)

            return response
    
        else:

            # Incorrect OTP: update attempts in database
            email_record.attempts += 1
            attempts = email_record.attempts

            log_security_event(username, "EMAIL_OTP_FAILED")

            if attempts >= 3:

                db.session.delete(email_record)
                db.session.commit()

                log_security_event(
                    username,
                    "EMAIL_OTP_TOO_MANY_ATTEMPTS"
                )

                return "Too many incorrect Email OTP attempts. Please login again."

            db.session.commit()

            return render_template(
                "email_otp.html",
                error=f"Invalid Email OTP. Attempt {attempts} of 3."
            )

    return render_template("email_otp.html")



# --- PROTECTED DASHBOARD --- #

@app.route("/dashboard")
def dashboard():

    if not session.get("authenticated") or not session.get("username"):
        return "Access denied. Please complete authentication first.", 403

    username = session.get("username")

    current_user = User.query.filter_by(username=username).first()

    if not current_user:
        return "User not found.", 404

    pending_requests = FriendRequest.query.filter_by(
        receiver_id=current_user.id,
        status="pending"
    ).count()
    unread_messages = ChatMessage.query.filter_by(
        receiver_id=current_user.id,
        is_read=False
    ).count()

    posts = Post.query.order_by(Post.created_at.desc()).all()
    comments_by_post = {}

    for post in posts:
        comments_by_post[post.id] = Comment.query.filter_by(
        post_id=post.id
    ).order_by(Comment.created_at.asc()).all()
    like_counts = {} 
    liked_post_ids = set()

    for post in posts:
        like_counts[post.id] = Like.query.filter_by(
        post_id=post.id
    ).count()

    user_like = Like.query.filter_by(
        post_id=post.id,
        user_id=current_user.id
    ).first()

    if user_like:
        liked_post_ids.add(post.id)
    return render_template(
        "dashboard.html",
        username=username,
        pending_requests=pending_requests,
        unread_messages=unread_messages,
        posts=posts,
        session_user_id=current_user.id,
        like_counts=like_counts,
        liked_post_ids=liked_post_ids,
        comments_by_post=comments_by_post

    )

# --- JWT PROTECTED API ROUTE --- #

@app.route("/jwt-protected", methods=["GET"])
@jwt_required()
def jwt_protected():

    current_user = get_jwt_identity()

    return {
        "message": "JWT authentication successful!",
        "authenticated_user": current_user
    }

# --- JWT REFRESH TOKEN ROUTE --- #
@csrf.exempt
@app.route("/refresh", methods=["POST"])
@jwt_required(refresh=True, locations=["cookies"])
def refresh():

    current_user = get_jwt_identity()
    current_token = get_jwt()
   
    try:
        # Find the existing refresh token
        result = db.session.execute(
            update(RefreshToken)
            .where(
                RefreshToken.jti == current_token["jti"],
                RefreshToken.username == current_user,
                RefreshToken.revoked == False
            )
            .values(revoked=True)
        )

        if result.rowcount != 1:
            db.session.rollback()
            return {"error": "Invalid or reused refresh token"}, 401
        

        # Generate new tokens
        new_access_token = create_access_token(
            identity=current_user
        )

        new_refresh_token = create_refresh_token(
            identity=current_user
        )

        # Decode the replacement refresh token
        refresh_data = decode_token(new_refresh_token)

        

        # Save the replacement refresh token
        new_token_record = RefreshToken(
            jti=refresh_data["jti"],
            username=current_user,
            expires_at=datetime.fromtimestamp(
                refresh_data["exp"],
                timezone.utc
            )
        )

        db.session.add(new_token_record)
        db.session.commit()


        response = make_response({
            "message": "Tokens refreshed successfully"
        })

        set_access_cookies(response, new_access_token)
        set_refresh_cookies(response, new_refresh_token)

        return response, 200

    except Exception:
        db.session.rollback()
        app.logger.exception("Refresh token rotation failed")
        return {"error": "Token refresh failed"}, 500


# --- USER PROFILE ---

@app.route("/profile", methods=["GET", "POST"])
def profile():

    # Check whether the user is logged in
    if not session.get("authenticated") or not session.get("username"):
        return redirect(url_for("login"))

    username = session.get("username")
    user = User.query.filter_by(username=username).first()

    if not user:
        return "User not found.", 404

    if request.method == "POST":

        bio = request.form.get("bio", "").strip()

        if len(bio) > 500:
            return render_template(
                "profile.html",
                user=user,
                error="Bio cannot exceed 500 characters."
            ), 400

        user.bio = bio
        db.session.commit()

        log_security_event(username, "PROFILE_UPDATED")

        return render_template(
            "profile.html",
            user=user,
            success="Profile updated successfully!"
        )

    return render_template("profile.html", user=user)
@app.route('/connect-telegram', methods=['GET', 'POST'])
def connect_telegram():
    
   # Identify the user who is registering or already logged in
    setup_user_id = session.get("telegram_setup_user_id")

    if setup_user_id:
        user = db.session.get(User, setup_user_id)

    elif session.get("authenticated") and session.get("username"):
        user = User.query.filter_by(
        username=session.get("username")
        ).first()

    else:
        flash('Please register or log in first.', 'error')
        return redirect(url_for('login'))

    if not user:
        flash('User not found.', 'error')
        return redirect(url_for('login'))

    
    # Reuse the existing linking code if it is still valid
    pending = TelegramLinkCode.query.filter_by(
        user_id=user.id
    ).first()

    session_code = session.get("telegram_link_code")
    session_code_user = session.get("telegram_link_code_user")

    if (
        pending
        and datetime.utcnow() <= pending.expires_at
        and session_code
        and session_code_user == user.id
        and hashlib.sha256(session_code.encode()).hexdigest() == pending.code_hash
    ):
        code = session_code

    else:
        # Generate a new code only when necessary
        code = secrets.token_urlsafe(16)
        code_hash = hashlib.sha256(code.encode()).hexdigest()

        # Remove any previous pending code
        TelegramLinkCode.query.filter_by(user_id=user.id).delete()

        link_code = TelegramLinkCode(
            user_id=user.id,
            code_hash=code_hash,
            expires_at=datetime.utcnow() + timedelta(minutes=5)
        )

        db.session.add(link_code)
        db.session.commit()

    # Keep the temporary code for page refreshes
        session["telegram_link_code"] = code
        session["telegram_link_code_user"] = user.id


    # Display the code to the user
    return render_template(
        'connect_telegram.html',
        code=code,
        bot_username=TELEGRAM_BOT_USERNAME
    )

@app.route('/verify-telegram', methods=['POST'])
def verify_telegram():

    setup_user_id = session.get("telegram_setup_user_id")

    if setup_user_id:
        user = db.session.get(User, setup_user_id)
        is_registration_setup = True

    elif session.get("authenticated") and session.get("username"):
        user = User.query.filter_by(
            username=session.get("username")
        ).first()
        is_registration_setup = False

    else:
        flash('Please register or log in first.', 'error')
        return redirect(url_for('login'))

    if not user:
        flash('User not found.', 'error')
        return redirect(url_for('login'))

    return_page = 'connect_telegram' if is_registration_setup else 'profile'

    pending = TelegramLinkCode.query.filter_by(
        user_id=user.id
    ).first()

    if not pending:
        flash('Please generate a Telegram linking code first.', 'error')
        return redirect(url_for(return_page))

    if datetime.utcnow() > pending.expires_at:
        db.session.delete(pending)
        db.session.commit()
        flash('Linking code expired. Please generate a new one.', 'error')
        return redirect(url_for(return_page))

    try:
        url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/getUpdates"

        response = requests.get(
            url,
            params={"timeout": 5},
            timeout=10
        )

        response.raise_for_status()
        result = response.json()

        if not result.get('ok'):
            flash('Could not communicate with Telegram.', 'error')
            return redirect(url_for(return_page))

        updates = result.get('result', [])

        for update in updates:
            message = update.get('message', {})
            telegram_text = message.get('text', '')

            if not telegram_text.startswith('/start '):
                continue

            received_code = telegram_text.split(maxsplit=1)[1].strip()
            received_hash = hashlib.sha256(
                received_code.encode()
            ).hexdigest()

            if received_hash != pending.code_hash:
                continue

            chat_id = str(message.get('chat', {}).get('id', ''))

            if not chat_id:
                continue

            existing_user = User.query.filter(
                User.telegram_chat_id == chat_id,
                User.id != user.id
            ).first()

            if existing_user:
                flash(
                    'This Telegram account is already linked to another user.',
                    'error'
                )
                return redirect(url_for(return_page))

            user.telegram_chat_id = chat_id
            user.telegram_verified = True

            db.session.delete(pending)
            db.session.commit()

            session.pop("telegram_link_code", None)
            session.pop("telegram_link_code_user", None)
            flash(
                'Your Telegram account has been connected successfully!',
                'success'
            )

            if is_registration_setup:
                session.pop("telegram_setup_user_id", None)
                return redirect(url_for('login'))

            return redirect(url_for('profile'))

        flash(
            'Linking code not received yet. Open your bot and press Start first.',
            'error'
        )

    except requests.RequestException:
        flash('Telegram connection failed. Please try again.', 'error')

    return redirect(url_for(return_page))


@app.route("/create-post", methods=["POST"])
def create_post():
    if not session.get("authenticated") or not session.get("username"):
        return redirect(url_for("login"))

    username = session.get("username")
    user = User.query.filter_by(username=username).first()

    if not user:
        return "User not found.", 404

    content = request.form.get("content", "").strip()
    image = request.files.get("image")

    if not content and (not image or not image.filename):
        return redirect(url_for("dashboard"))

    if len(content) > 2000:
        return "Post cannot exceed 2000 characters.", 400

    image_filename = None

    if image and image.filename:
        original_filename = secure_filename(image.filename)

        if "." not in original_filename:
            return "Invalid image file.", 400

        extension = original_filename.rsplit(".", 1)[1].lower()

        if extension not in ALLOWED_EXTENSIONS:
            return "Only JPG, JPEG, PNG and WEBP images are allowed.", 400

        image_filename = f"{secrets.token_hex(8)}.{extension}"
        image_path = os.path.join(UPLOAD_FOLDER, image_filename)
        image.save(image_path)

    post = Post(
        user_id=user.id,
        content=content,
        image_filename=image_filename
    )

    try:
        db.session.add(post)
        db.session.commit()
    except Exception:
        db.session.rollback()

        if image_filename:
            image_path = os.path.join(UPLOAD_FOLDER, image_filename)
            if os.path.exists(image_path):
                os.remove(image_path)

        raise

    log_security_event(username, "POST_CREATED")

    return redirect(url_for("dashboard"))

@app.route("/delete-post/<int:post_id>", methods=["POST"])
def delete_post(post_id):

    if not session.get("authenticated") or not session.get("username"):
        return redirect(url_for("login"))

    user = User.query.filter_by(
        username=session.get("username")
    ).first()

    if not user:
        return redirect(url_for("login"))

    post = Post.query.filter_by(
        id=post_id,
        user_id=user.id
    ).first()

    if not post:
        return "Post not found or you are not allowed to delete it.", 404

    db.session.delete(post)
    db.session.commit()

    log_security_event(user.username, "POST_DELETED")

    return redirect(url_for("dashboard"))

@app.route("/like-post/<int:post_id>", methods=["POST"])
def like_post(post_id):

    if not session.get("authenticated") or not session.get("username"):
        return redirect(url_for("login"))

    user = User.query.filter_by(
        username=session.get("username")
    ).first()

    if not user:
        return redirect(url_for("login"))

    post = Post.query.get_or_404(post_id)

    existing_like = Like.query.filter_by(
        user_id=user.id,
        post_id=post.id
    ).first()

    if existing_like:
        db.session.delete(existing_like)
        event = "POST_UNLIKED"
    else:
        new_like = Like(
            user_id=user.id,
            post_id=post.id
        )
        db.session.add(new_like)
        event = "POST_LIKED"

    db.session.commit()
    log_security_event(user.username, event)

    return redirect(url_for("dashboard"))

@app.route("/add-comment/<int:post_id>", methods=["POST"])
def add_comment(post_id):

    if not session.get("authenticated") or not session.get("username"):
        return redirect(url_for("login"))

    user = User.query.filter_by(
        username=session.get("username")
    ).first()

    if not user:
        return redirect(url_for("login"))

    post = Post.query.get_or_404(post_id)

    content = request.form.get("content", "").strip()

    if not content:
        return redirect(url_for("dashboard"))

    if len(content) > 1000:
        return "Comment cannot exceed 1000 characters.", 400

    comment = Comment(
        user_id=user.id,
        post_id=post.id,
        content=content
    )

    db.session.add(comment)
    db.session.commit()

    log_security_event(user.username, "COMMENT_CREATED")

    return redirect(url_for("dashboard"))

# --- SEARCH USERS ---

@app.route("/search-users")
def search_users():

    if not session.get("authenticated") or not session.get("username"):
        return redirect(url_for("login"))

    query = request.args.get("q", "").strip()
    current_username = session.get("username")

    users = []

    if query:
        users = User.query.filter(
            User.username.ilike(f"%{query}%"),
            User.username != current_username
        ).all()

    return render_template(
        "search_users.html",
        users=users,
        query=query
    )
# --- SEND FRIEND REQUEST ---

@app.route("/send-friend-request/<int:receiver_id>", methods=["POST"])
def send_friend_request(receiver_id):

    if not session.get("authenticated") or not session.get("username"):
        return redirect(url_for("login"))

    sender = User.query.filter_by(
        username=session.get("username")
    ).first()

    receiver = User.query.get(receiver_id)

    if not sender or not receiver:
        return "User not found.", 404

    if sender.id == receiver.id:
        return "You cannot send a request to yourself.", 400

    existing = FriendRequest.query.filter_by(
        sender_id=sender.id,
        receiver_id=receiver.id
    ).first()

    reverse = FriendRequest.query.filter_by(
        sender_id=receiver.id,
        receiver_id=sender.id
    ).first()

    if existing and existing.status in ["pending", "accepted"]:
        return "Friend request already exists.", 400

    if reverse and reverse.status in ["pending", "accepted"]:
        return "This user has already sent you a friend request.", 400

    if existing:
        existing.status = "pending"
        existing.created_at = datetime.utcnow()
    else:
        new_request = FriendRequest(
            sender_id=sender.id,
            receiver_id=receiver.id,
            status="pending"
        )
        db.session.add(new_request)

    db.session.commit()

    log_security_event(sender.username, "FRIEND_REQUEST_SENT")

    return redirect(url_for(
        "search_users",
        q=request.form.get("q", "")
    ))
# --- VIEW INCOMING FRIEND REQUESTS ---

@app.route("/friend-requests")
def friend_requests():

    if not session.get("authenticated") or not session.get("username"):
        return redirect(url_for("login"))

    current_user = User.query.filter_by(
        username=session.get("username")
    ).first()

    if not current_user:
        return redirect(url_for("login"))

    requests_received = FriendRequest.query.filter_by(
        receiver_id=current_user.id,
        status="pending"
    ).all()

    incoming_requests = []

    for friend_request in requests_received:
        sender = User.query.get(friend_request.sender_id)

        if sender:
            incoming_requests.append({
                "request_id": friend_request.id,
                "username": sender.username
            })

    return render_template(
        "friend_requests.html",
        incoming_requests=incoming_requests
    )

# --- MESSAGES WORKSPACE ---

@app.route("/messages")
def messages_home():

    if not session.get("authenticated") or not session.get("username"):
        return redirect(url_for("login"))

    current_user = User.query.filter_by(
        username=session.get("username")
    ).first()

    if not current_user:
        return redirect(url_for("login"))

    friendships = FriendRequest.query.filter(
        FriendRequest.status == "accepted",
        db.or_(
            FriendRequest.sender_id == current_user.id,
            FriendRequest.receiver_id == current_user.id
        )
    ).all()

    friends = []

    for friendship in friendships:
        friend_id = (
            friendship.receiver_id
            if friendship.sender_id == current_user.id
            else friendship.sender_id
        )

        friend = User.query.get(friend_id)

        if friend:
            friends.append(friend)

    unread_counts = {}

    for friend in friends:
        unread_counts[friend.id] = ChatMessage.query.filter_by(
            sender_id=friend.id,
            receiver_id=current_user.id,
            is_read=False
        ).count()

    return render_template(
        "messages.html",
        friends=friends,
        friend=None,
        conversation=[],
        current_user=current_user,
        unread_counts=unread_counts
    )


# --- MY FRIENDS ---

@app.route("/my-friends")
def my_friends():
    return redirect(url_for("messages_home"))


# --- PRIVATE MESSAGES ---

@app.route("/messages/<int:friend_id>", methods=["GET", "POST"])
def messages(friend_id):

    if not session.get("authenticated") or not session.get("username"):
        return redirect(url_for("login"))

    current_user = User.query.filter_by(
        username=session.get("username")
    ).first()

    if not current_user:
        return redirect(url_for("login"))

    friend = User.query.get_or_404(friend_id)

    if current_user.id == friend.id:
        return "You cannot message yourself.", 400

    # Check accepted friendship
    friendship = FriendRequest.query.filter(
        FriendRequest.status == "accepted",
        db.or_(
            db.and_(
                FriendRequest.sender_id == current_user.id,
                FriendRequest.receiver_id == friend.id
            ),
            db.and_(
                FriendRequest.sender_id == friend.id,
                FriendRequest.receiver_id == current_user.id
            )
        )
    ).first()

    if not friendship:
        return "You can only message accepted friends.", 403

    # Send message
    if request.method == "POST":

        content = request.form.get("content", "").strip()

        if not content:
            return redirect(url_for("messages", friend_id=friend.id))

        if len(content) > 2000:
            return "Message cannot exceed 2000 characters.", 400

        message = ChatMessage(
            sender_id=current_user.id,
            receiver_id=friend.id,
            content=content
        )

        db.session.add(message)
        db.session.commit()

        log_security_event(current_user.username, "MESSAGE_SENT")

        return redirect(url_for("messages", friend_id=friend.id))

    # Mark incoming messages as read
    ChatMessage.query.filter_by(
        sender_id=friend.id,
        receiver_id=current_user.id,
        is_read=False
    ).update({"is_read": True})

    db.session.commit()

    # Retrieve conversation
    conversation = ChatMessage.query.filter(
        db.or_(
            db.and_(
                ChatMessage.sender_id == current_user.id,
                ChatMessage.receiver_id == friend.id
            ),
            db.and_(
                ChatMessage.sender_id == friend.id,
                ChatMessage.receiver_id == current_user.id
            )
        )
    ).order_by(ChatMessage.created_at.asc()).all()

    # Retrieve all accepted friends
    friendships = FriendRequest.query.filter(
        FriendRequest.status == "accepted",
        db.or_(
            FriendRequest.sender_id == current_user.id,
            FriendRequest.receiver_id == current_user.id
        )
    ).all()

    friends = []

    for friendship in friendships:
        friend_id_in_list = (
            friendship.receiver_id
            if friendship.sender_id == current_user.id
            else friendship.sender_id
        )

        friend_user = User.query.get(friend_id_in_list)

        if friend_user:
            friends.append(friend_user)

    unread_counts = {}

    for friend_user in friends:
        unread_counts[friend_user.id] = ChatMessage.query.filter_by(
            sender_id=friend_user.id,
            receiver_id=current_user.id,
            is_read=False
        ).count()

    return render_template(
        "messages.html",
        friends=friends,
        friend=friend,
        conversation=conversation,
        current_user=current_user,
        unread_counts=unread_counts
    )

# --- ACCEPT OR REJECT FRIEND REQUEST ---

@app.route("/respond-friend-request/<int:request_id>", methods=["POST"])
def respond_friend_request(request_id):

    if not session.get("authenticated") or not session.get("username"):
        return redirect(url_for("login"))

    current_user = User.query.filter_by(
        username=session.get("username")
    ).first()

    if not current_user:
        return redirect(url_for("login"))

    friend_request = FriendRequest.query.filter_by(
        id=request_id,
        receiver_id=current_user.id,
        status="pending"
    ).first()

    if not friend_request:
        return "Friend request not found.", 404

    action = request.form.get("action")

    if action == "accept":
        friend_request.status = "accepted"
        event = "FRIEND_REQUEST_ACCEPTED"

    elif action == "reject":
        friend_request.status = "rejected"
        event = "FRIEND_REQUEST_REJECTED"

    else:
        return "Invalid action.", 400

    db.session.commit()

    log_security_event(current_user.username, event)

    return redirect(url_for("friend_requests"))
# --- LOGOUT --- #

@app.route("/logout", methods=["POST"])
@csrf.exempt
@jwt_required(refresh=True, locations=["cookies"])
def logout():
    current_user = get_jwt_identity()
    current_token = get_jwt()

    try:
        result = db.session.execute(
            update(RefreshToken)
            .where(
                RefreshToken.jti == current_token["jti"],
                RefreshToken.username == current_user,
                RefreshToken.revoked == False
            )
            .values(revoked=True)
        )

        if result.rowcount != 1:
            db.session.rollback()
            return {"error": "Invalid or already revoked token"}, 401

        db.session.commit()

        log_security_event(current_user, "LOGOUT")
        session.clear()

        response = make_response(redirect("/login"))
        unset_jwt_cookies(response)

        return response

    except Exception:
        db.session.rollback()
        app.logger.exception("Logout failed")
        return {"error": "Logout failed"}, 500



#---START FLASK--#
if __name__ == "__main__":
    app.run(debug=True)

